/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shishulinaei_15.раздел1;

/**
 *
 * @author Student
 */
public class zadanie_65 {

    private static String[] b;

    /**
     * @param args the command line arguments
     * @param a
     */
    public static void main(String[] args, String[] a) {
        // TODO code application logic here
         int[] array15 = new int[10];
int[] A15 = new int[10];
int[] B15= new int[10];
int[] C15 = new int[10];
int sumc15=0;
float sr_sumc15=0;
int min = Integer.MIN_VALUE;
int max = Integer.MAX_VALUE;

System.out.println("Сформировать массивы A,B и C, содержащие по 10 целых случайных чисел.\n" +
"Найти среднее арифметическое элементов каждого массива. Создать процедуру\n" +
"для формирования массива и определения среднего арифметического его\n" +
"элементов.");

System.out.println("Исходный массив: ");
for (int i15 = 0; i15 < array15.length; i15++) {
array15[i15]=(int) (Math.random()*10-10);
System.out.print(array15[i15]+" ");
}
System.out.println("");

        for (int i = 0; i < C15.length; i++) {
            sumc15=sumc15+C15[i];
            
        }
        sr_sumc15 = sumc15 / C15.length;
        System.out.println(sr_sumc15);

}
    }
    

    
    

