/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shishulinaei_15.раздел1;

/**
 *
 * @author Student
 */
public class zadanie_15 {

    private static int[] array15;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
       
        int max = Integer.MAX_VALUE;
        int min = Integer.MIN_VALUE;
        System.out.println("Дан массив из n чисел как положительных, так и отрицательных. Нужно\n" +
"сначала записать положительные числа, а затем отрицательные в том же порядке,\n" +
"как они были записаны в исходном массиве.");
        
          System.out.println("Исходный массив: ");
          
for (int i15 = 0; i15 < array15.length; i15++) {
array15[i15]=(int) (Math.random()*200-100);
System.out.print(array15[i15]+" ");
}
System.out.println("");
//Поиск минимального числа
for (int i15 = 0; i15 < array15.length; i15++) {

if (array15[i15]< min){

min = array15[i15];
}
}
System.out.println("Минимальный элемент"+max);
//формирование массивов по заданию
for (int i15 = 0; i15 < array15.length; i15++) {
//Проверка на четность
if(i15 % 2==0){
    //System.out.print(b[i]+" ");
}
System.out.println("");
}
    }
}

   