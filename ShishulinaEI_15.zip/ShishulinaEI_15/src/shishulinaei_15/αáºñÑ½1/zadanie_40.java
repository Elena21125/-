/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shishulinaei_15.раздел1;

/**
 *
 * @author Student
 */
public class zadanie_40 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args{
        // TODO code application logic here
        
        min = Integer.MAX_VALUE;
        max = Integer.MAX_VALUE;
      
        System.out.println("В массиве хранятся цены на 15 видов товаров. С помощью датчика\n" +
"случайных чисел заполнить массив целыми значениями, лежащими в диапазоне\n" +
"от 20 до 300 включительно. Определить цену самого дешевого товара и его\n" +
"порядковый номер.");
          
        System.out.println("Исходный массив: ");
        int[] array15 = null;
for (int i15 = 0; i15 < array15.length; i15++) {
array15[i15]=(int) (Math.random()*20-300);
System.out.print(array15[i15]+" ");
}
System.out.println("");
//Поиск минимального числа
for (int i15 = 0; i15 < array15.length; i15++) {

if (array15[i15]< min){

min = array15[i15];
}
}
System.out.println("Минимальный элемент"+max);
//формирование массивов по заданию
for (int i15 = 0; i15 < array15.length; i15++) {
//Проверка на четность
if(i15 % 2==0)

    
    

